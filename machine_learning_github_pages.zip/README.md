# Machine Learning — Belajar dari Data

Website edukasi sederhana tentang Machine Learning.

## Cara menjalankan
Buka `index.html` di browser.

## GitHub Pages
Upload seluruh isi folder ini ke repository GitHub, lalu aktifkan:
**Settings → Pages → Deploy from a branch → main → /(root)**

Setelah deployment selesai, GitHub akan memberikan URL website.
